<!doctype html>
<html>
<head>
<title></title>







</head>

<body>


<form action="" method="POST">

<input type="email" name="email"
placeholder="Enter your email"/>





</form>












</body>
</html>